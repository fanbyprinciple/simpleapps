# Chess
Python full gui 2-player chess with pygame
Mainly created to practice pygame and python. To install and try, clone or download the repo and change the image file paths in main.py to point to the images in the repo. Make sure you have pygame installed for python 3.

NOTE: Much of the chess logic is unfinished as this was a simple excercise into building an app with pygame
