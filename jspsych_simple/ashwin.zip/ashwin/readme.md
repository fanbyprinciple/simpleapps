# JSPsych simple experiment

Taken from : https://www.jspsych.org/tutorials/rt-task/

## Simple reaction test experiment

![](jspsych_simple.gif)
